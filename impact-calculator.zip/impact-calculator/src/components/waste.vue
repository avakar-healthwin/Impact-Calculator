<template>
  <div class="main-container">
      <div class="container">
          <div class="title">Waste Generated</div>
          <p>Your household generates {{total_waste_gen}} tonnes of waste in its lifetime.</p>
          <img src="../assets/balance1.png" alt="">
          <h2>It is as heavy as {{no_of_buses}} buses.</h2>
          <button v-on:click="replaceWaste()" class="btn-1">See Carbon Footprint </button>
          <button v-on:click="openLoading2()" class="btn-2">Check your compost</button>
      </div>
  </div>
</template>

<script>

export default {
  components:{
    
  },
  data () {
    return {
      total_waste_gen:0,
      no_of_buses:0,
    }
  },
  methods:{
    replaceWaste(){
      this.$router.replace('/carbon');
    },
    openLoading2(){
        this.$router.replace('/loading2');
    },
  },
  mounted(){
      this.total_waste_gen = this.data.members*0.5*365*60*0.00110231;
      this.total_waste_gen = this.total_waste_gen.toFixed(2);
      this.no_of_buses = this.total_waste_gen/20;
      this.no_of_buses = this.no_of_buses.toFixed(1);
      console.log(this.data);
  },
  props:['data']
}
</script>

<style lang='scss' scoped>
*{
      font-family: Titillium Web;
      margin: 0px;
      padding: 0px;
}
.main-container{
  width: 100%;
  background: #40050C;
  height: 100vh;
}
.container{
  display: flex;
  flex-flow: column nowrap;
  justify-content: center;
  align-items: center;
}
.container .title{
  max-width: 60%;
  font-family: Titillium Web;
  font-style: normal;
  font-weight: 900;
  font-size: 72px;
  line-height: 105px;
  /* or 146% */

  display: flex;
  align-items: center;

  color: #FFFFFF;
}
.container p{
  font-family: Titillium Web;
  font-style: normal;
  font-weight: 300;
  font-size: 36px;
  line-height: 55px;
  display: flex;
  align-items: center;
  letter-spacing: -0.015em;

  /* Gray 6 */

  color: #F2F2F2;
}
.container img{
  max-width: 80%;
  width: 650px;
  height: 600px;
  height: auto;
}
.container h2{
  max-width: 60%;
  font-family: Titillium Web;
  font-style: normal;
  font-weight: 600;
  font-size: 48px;
  line-height: 73px;
  display: flex;
  align-items: center;
  text-align: center;
  letter-spacing: -0.015em;

  /* Gray 6 */

  color: #F2F2F2;
  margin-bottom: 20px;
}
.container .btn-1{
  background: #661016;
  border-radius: 64px;
  font-family: Titillium Web;
  font-style: normal;
  font-weight: 900;
  font-size: 24px;
  line-height: 40px;
  /* or 292% */

  display: flex;
  align-items: center;
  justify-content: center;
  color: #FFFFFF;
  max-width: 40%;
  height: 50px;
  width: 400px;
  margin-bottom: 20px;
  border: none;
  outline: none;
  opacity: 0.5;
}
.container .btn-2{
  background: #40050C;
  border-radius: 50px;
  font-family: Titillium Web;
  font-style: normal;
  font-weight: 900;
  font-size: 36px;
  line-height: 55px;
  /* identical to box height */

  display: flex;
  align-items: center;
  text-align: center;
  letter-spacing: 0.05em;

  color: #FFFFFF;
  max-width: 60%;
  height: 60px;
  width: 550px;
  justify-content: center;
  border: 2px solid #7ABBB0;
  outline: none;
}
.container .btn-2:hover{
   background: #7ABBB0;
   cursor: pointer;
}
.container .btn-1:hover{
  cursor: pointer;
}

</style>
