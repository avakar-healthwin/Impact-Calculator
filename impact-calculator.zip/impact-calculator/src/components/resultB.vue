<template>
  <div class="main-container">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" 
        href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" 
        integrity="sha384-hWVjflwFxL6sNzntih27bfxkr27PmbbK/iSvJ+a4+0owXq79v+lsFkW54bOGbiDQ" 
        crossorigin="anonymous">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Titillium+Web:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link href='https://cdn.jsdelivr.net/npm/boxicons@2.0.5/css/boxicons.min.css' rel='stylesheet'>
    <img class="top-img" src="../assets/resultB.gif" alt="">
    <div class="title">
         <h1>Congratulations! You have contributed significantly to the welfare of the society!</h1>
     </div>
    <div class="container">
      <h1>Your compost can fertilize {{no_of_fields}} crop fields and help farmers save {{amount}} amount.</h1>
      <img src="../assets/balance1.png" alt="">
      <h2>You just reduced your household waste by 40%! </h2>
    </div>
    <router-link to="/resultA"><i class="fas fa-arrow-left"></i></router-link>
  </div>
</template>

<script>
export default {
  data () {
    return {
      no_of_fields:0,
      amount:0,
    }
  },
  mounted(){
    var total_waste_gen = this.data.members*0.5*365*70*0.00110231;
    this.no_of_fields = (total_waste_gen*0.7*0.4)/2.625;
    this.no_of_fields = this.no_of_fields.toFixed(2);
    this.amount = total_waste_gen*0.7*0.4*50*1000;
    this.amount = this.amount.toFixed(2);
  },
  props:['data']
}
</script>

<style lang='scss' scoped>
*{
      font-family: Titillium Web;
      margin: 0px;
      padding: 0px;
}
.main-container{
  background: #40050C;
  height: 100vh;
}
.title{
    max-width: 100%;
    height: 20%;
    background: rgba(191, 41, 46, 0.7);
    border-radius: 0 0 50px 50px;
    display: flex;
    justify-content: center;
    align-items: center;
}
.title h1{
  max-width: 60%;
  font-family: Titillium Web;
  font-style: normal;
  font-weight: 900;
  font-size: 36px;
  line-height: 55px;
  display: flex;
  align-items: center;
  text-align: center;
  letter-spacing: 0.05em;

color: #FFFFFF;
}
.top-img{
  position: absolute;
  top: 0;
  left: 45%;
  text-align: center;;
  height: 150px;
  width: 200px;
}
.container{
  display: flex;
  flex-flow: column nowrap;
  justify-content: center;
  align-items: center;
}
.container h1{
  padding-top: 20px;
  max-width: 70%;
  font-family: Titillium Web;
  font-style: normal;
  font-weight: 600;
  font-size: 36px;
  line-height: 55px;
  display: flex;
  align-items: center;
  text-align: center;
  letter-spacing: 0.05em;

  color: #70D3CB;

}
.container img{
  max-width: 80%;
  width: 650px;
  height: 600px;
  height: auto;
}
.container h2{
  padding-top: 20px;
  max-width: 80%;
  font-family: Titillium Web;
  font-style: normal;
  font-weight: 900;
  font-size: 48px;
  line-height: 73px;
  display: flex;
  align-items: center;
  text-align: center;
  letter-spacing: 0.05em;

  color: #FFFFFF;

}
i{
    position: absolute;
    left: 4%;
    bottom: 8%;
    color: white;
    font-size: 24px;
    box-sizing: border-box;
    border: 1px solid #70D3CB;
    padding: 6px;
    border-radius: 50%;
}

</style>
