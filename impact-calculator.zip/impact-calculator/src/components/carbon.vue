<template>
  <div class="main-container">
      <div class="container">
          <h1>Carbon Footprint </h1>
          <p>Your vehicles produce {{co2_by_vehicles}} kg of CO2 every year!</p>
          <img src="../assets/carbon1.png" alt="">
          <p>If you would plant {{no_of_trees}} trees, you could actually compensate the carbon dioxide emitted by your household vehicles! </p>
          <div class="button">
              <button v-on:click="replaceCarbon()" class="btn-1">See Waste Generated </button>
              <button v-on:click="openLoading2()" class="btn-2">Check your compost</button>
          </div>
      </div>
  </div>
</template>

<script>

export default {
  components:{
    
  },
  data () {
    return {
      co2_by_vehicles:0,
      no_of_trees:0,
    }
  },
  methods:{
    replaceCarbon(){
      this.$router.replace('/waste');
    },
    openLoading2(){
        this.$router.replace('/loading2');
    },
  },
  mounted(){
      this.co2_by_vehicles = (this.data.diesel_cars*5400) + (this.data.petrol_cars*4600) + (this.data.bikes*2030) + (this.data.scooty*1700);
      this.co2_by_vehicles = this.co2_by_vehicles.toFixed(2);
      this.no_of_trees = ((this.data.diesel_cars*5400)/25) + ((this.data.petrol_cars*4600)/25) + ((this.data.bikes*2030)/25) + ((this.data.scooty*1700)/25);
      this.no_of_trees = this.no_of_trees.toFixed(2);
  },
  props:['data']
}
</script>

<style lang='scss' scoped>
*{
      font-family: Titillium Web;
      margin: 0px;
      padding: 0px;
    }
.main-container{
    max-width: 100%;
    height: 100vh;
    // height: 100%;
    background: #40050C;
}
.container{
  display: flex;
  flex-flow: column nowrap;
//   justify-content: center;
  align-items: flex-start;
  padding-left: 80px;
  padding-top: 50px;
}
.container h1{
    font-family: Titillium Web;
    font-style: normal;
    font-weight: 900;
    font-size: 72px;
    line-height: 105px;
    /* or 146% */

    display: flex;
    align-items: center;

    color: #FFFFFF;
}
.container p{
    font-family: Titillium Web;
    font-style: normal;
    font-weight: 300;
    font-size: 36px;
    line-height: 45px;
    display: flex;
    align-items: center;
    letter-spacing: -0.015em;

    /* Gray 6 */

    color: #F2F2F2;
    max-width: 80%;
}
.container img{
    max-width: 80%;
    width: 40%;
    height: 400px;
    height: auto;
    position: relative;
    left: 0px;
    right: 0px;
}
.container .button{
    display: flex;
    flex-flow: column;
    justify-content: center;
    align-items: center;
    max-width: 100%;
    padding-top: 10px;
    width: 100%;
}
.container .button .btn-1{
  background: #661016;
  border-radius: 64px;
  font-family: Titillium Web;
  font-style: normal;
  font-weight: 900;
  font-size: 24px;
  line-height: 40px;
  /* or 292% */

  display: flex;
  align-items: center;
  justify-content: center;
  color: #FFFFFF;
  max-width: 40%;
  height: 50px;
  width: 400px;
  margin-bottom: 20px;
  border: none;
  outline: none;
  opacity: 0.5;
  align-self: center;
}

.container .button .btn-2{
  background: #40050C;
  border-radius: 50px;
  font-family: Titillium Web;
  font-style: normal;
  font-weight: 900;
  font-size: 36px;
  line-height: 55px;
  /* identical to box height */

  display: flex;
  align-items: center;
  text-align: center;
  letter-spacing: 0.05em;

  color: #FFFFFF;
  max-width: 60%;
  height: 60px;
  width: 550px;
  justify-content: center;
  border: 2px solid #7ABBB0;
  outline: none;
}
.container .btn-2:hover{
   background: #7ABBB0;
   cursor: pointer;
}
.container .btn-1:hover{
  cursor: pointer;
}
</style>
